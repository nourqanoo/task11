package com.donation.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class AddNeed extends AppCompatActivity {

    ArrayList<String>sections;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_need);

        Spinner spin = (Spinner) findViewById(R.id.spinner);

        sections=new ArrayList<>();

        sections.add("قسم 1");
        sections.add("قسم 2");
        sections.add("قسم 3");

        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,sections);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);

    }
}
